#ifndef STRUCTS_FILA_H
#define STRUCTS_FILA_H

/* ------------------------------- */
struct dFila{
    pDLista pdLista;
};

#endif
