void imprimrListaDeLista(pDLista pd, FuncaoImpressao pfi){
    
    pNoh aux;
    aux = pd->primeiro;

    while(aux != NULL){

        imprimirLista(aux->info,pfi);

       aux = aux->prox;
    }
}